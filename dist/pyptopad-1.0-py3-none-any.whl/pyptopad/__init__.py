""" Pyptopad: python crypto pad

Pyptopad is free software: see the file LICENSE for copying conditions.
"""
